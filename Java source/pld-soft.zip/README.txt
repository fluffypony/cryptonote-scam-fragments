How to use PaladinCoin?

1. Download this archive. Inside you will find two folders you need for work and a library called cn_native_hash.dll.

2. Place the cn_native_hash.dll file into the library catalogue of your Java-machine (bin folder). 

Windows users usually see the address of the folder as 
C:\Program Files\Java\jre-your-version\bin

If you don't have Java yet, please download it from www.java.com.

Please note that PaladinCoin will work only with a 64-bit version of Java. 

3. In paladin-wallet folder you can find a file named config.properties. Just open it with Notepad.

4. You need to type in your IP (you can learn it by typing in ipconfig in the command line) into the second line of the config file. 

In line 6 please type in the port of the wallet, we usually recommend to use 8081 (it should be different from the miner port). Then save the file.

4a. If you want to add your IP address to the node peer list please send PM to our admin at the forum.
4b. You may replace node peer list for the wallet with "your-ip:miner-port" (see step 9 below).

5. Open the command line and enter the address of the folder by using cd command.

e.g.: cd C:\User\PaladinCoin\pld-wallet

6. In order to launch the wallet you need to enter: java -Xss4m -jar pld-wallet.jar config.properties

7. Now after you see the menu press 1 to learn the address of your wallet, then copy it.

8. Now open the config.properties file located in the pld-miner folder. Enter the address of your wallet to line 22.

9. Enter your IP to line 2. Enter your miner port to line 6. We recommend to use 8080 (it must be different from the wallet port). Save the file.

10. To exit the wallet enter 4.

11. Launch the miner by using the command line. Type in the address to the folder containing the miner. 

E.g.: cd C:\User\PaladinCoin\pld-miner

12. To load the miner enter:  java -Xss4m -jar pld-miner.jar config.properties

13. Now you can automatically mine the coins to the wallet noted in the config file.
 
Also in order to get the coins you can contact the forum admins.

14. Launch the wallet. To complete the transaction enter 3 and follow the instructions.

15. Good luck with trading!